package com.sapient.ecommerce.dbaccess.dbschema;

public class Brand {

	long brandId;
	
	String brandName;
}
