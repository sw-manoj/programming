package com.sapient.ecommerce.dbaccess.dbschema;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class Category {

	String categoryType;
	String categoryid;
	
	//key is like shoe,pant,jean,shorts etc..
	ConcurrentHashMap<String, List<Product>> productMap = new ConcurrentHashMap<String, List<Product>>();
}
