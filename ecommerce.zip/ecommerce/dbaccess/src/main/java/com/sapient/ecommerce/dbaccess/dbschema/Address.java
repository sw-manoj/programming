package com.sapient.ecommerce.dbaccess.dbschema;

public class Address {

	String addressId;
	
	String doorNo;
	
	String streetName;
	
	String city;
	
	String pincode;
}
