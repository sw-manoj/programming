package com.sapient.ecommerce.dbaccess.dbschema;

public enum Size {

	SMALL,MEDIUM,LARGE,XL,XXL;
}
