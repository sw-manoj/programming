package com.sapient.ecommerce.dbaccess.dbschema;

public enum Gender {
	MALE,FEMALE
}
