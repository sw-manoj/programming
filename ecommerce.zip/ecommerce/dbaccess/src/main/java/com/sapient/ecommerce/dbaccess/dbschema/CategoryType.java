package com.sapient.ecommerce.dbaccess.dbschema;

public enum CategoryType {

	MEN,WOMEN,MEN_KIDS, WOMEN_KID;
}
