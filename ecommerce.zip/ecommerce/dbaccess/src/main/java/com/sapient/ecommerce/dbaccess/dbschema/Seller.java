package com.sapient.ecommerce.dbaccess.dbschema;

public class Seller {

	String sellerId;
	
	String sellerName;
	
	String desc;
}
