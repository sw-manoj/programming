package com.sapient.ecommerce.dbaccess.dbschema;

import java.util.List;

public class Customer {

	String customerId;
	
	String customerName;
	
	List<Address> address;
	
	
}
